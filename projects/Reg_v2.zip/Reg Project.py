from PyPDF2 import PdfFileReader
from tika import parser
import sounddevice as sd
from scipy.io.wavfile import write
import speech_recognition as sr
import wavio
import pyttsx3
import nltk
import string
import operator
import re
import math
# Set up pyttsx3 text to speech
engine = pyttsx3.init()


# get_info from https://www.blog.pythonlibrary.org/2018/06/07/an-intro-to-pypdf2/
def get_info(path):
    with open(path, 'rb') as f:
        pdf = PdfFileReader(f)
        number_of_pages = pdf.getNumPages()
        return number_of_pages


def text_extractor(path, page):
    # Take text from pdf and convert it to a string
    with open(path, 'rb') as f:
        pdf = PdfFileReader(f)
        page = pdf.getPage(page)
        print(page)
        print('Page type: {}'.format(str(type(page))))
        text = page.extractText()
        return text


def pdf_to_text(path, towrite):
    # Write pdf text to text file
    with open(towrite, 'w', encoding='utf-8') as f:
        pagetext = parser.from_file(path)
        output = pagetext['content']
        f.write(output)
        return output


def tokenize(rules):

    # Break string into separate words
    base_words = nltk.word_tokenize(rules)

    # Create list to store final words in
    words = []

    # Append words to final list that are not punctuation or stopwords
    for word in base_words:
        if word[0] in string.punctuation or word.lower() in badwords:
            continue

        words.append(word.lower())

    return words


# Thanks to this thread for the code: https://stackoverflow.com/questions/4576077/how-can-i-split-a-text-into-sentences
def split_into_sentences(text):
    alphabets = "([A-Za-z])"
    prefixes = "(Mr|St|Mrs|Ms|Dr)[.]"
    suffixes = "(Inc|Ltd|Jr|Sr|Co)"
    starters = "(Mr|Mrs|Ms|Dr|He\s|She\s|It\s|They\s|Their\s|Our\s|We\s|But\s|However\s|That\s|This\s|Wherever)"
    acronyms = "([A-Z][.][A-Z][.](?:[A-Z][.])?)"
    websites = "[.](com|net|org|io|gov)"
    digits = "([0-9])"

    text = " " + text + "  "
    text = text.replace("\n"," ")
    text = re.sub(prefixes,"\\1<prd>",text)
    text = re.sub(websites,"<prd>\\1",text)
    if "Ph.D" in text: text = text.replace("Ph.D.","Ph<prd>D<prd>")
    text = re.sub("\s" + alphabets + "[.] "," \\1<prd> ",text)
    text = re.sub(acronyms+" "+starters,"\\1<stop> \\2",text)
    text = re.sub(alphabets + "[.]" + alphabets + "[.]" + alphabets + "[.]","\\1<prd>\\2<prd>\\3<prd>",text)
    text = re.sub(alphabets + "[.]" + alphabets + "[.]","\\1<prd>\\2<prd>",text)
    text = re.sub(" "+suffixes+"[.] "+starters," \\1<stop> \\2",text)
    text = re.sub(" "+suffixes+"[.]"," \\1<prd>",text)
    text = re.sub(" " + alphabets + "[.]"," \\1<prd>",text)
    text = re.sub(digits + "[.]" + digits, "\\1<prd>\\2", text)
    if "”" in text: text = text.replace(".”","”.")
    if "\"" in text: text = text.replace(".\"","\".")
    if "!" in text: text = text.replace("!\"","\"!")
    if "?" in text: text = text.replace("?\"","\"?")
    text = text.replace(".",".<stop>")
    text = text.replace("?","?<stop>")
    text = text.replace("!","!<stop>")
    text = text.replace("<prd>",".")

    sentences = text.split("<stop>")
    sentences = sentences[:-1]
    sentences = [s.strip() for s in sentences]

    # for sentence in sentences:
    #     print(sentence + "\n")

    return sentences


def load_files(files):

    mapped_files = {}

    for file in files:
        fileName = file + ".pdf"
        text = split_into_sentences(pdf_to_text(fileName, "Text.txt"))
        words = []
        for sentence in text:
            sentence_words = tokenize(sentence)
            for word in sentence_words:
                words.append(word)

        mapped_files[file] = words

    return mapped_files


def compute_idfs(documents):

    # Create dictionary to store words and idf values
    idfs = {}

    for file in documents:
        for word in documents[file]:
            # Skip words that have already been calculated
            if word in idfs:
                continue

            # Count number of docs each word is in
            in_docs = 0
            for document in documents:
                if word in documents[document]:
                    in_docs += 1

            # Calculate idfs based on values and record into dictionary
            idfs[word] = math.log(len(documents) / in_docs)

    return idfs


def top_answer(query, sentences, idfs):

    # Create list of tuples to store sentence and values
    sentence_scores = []

    # Count # of query words in sentence and # of sentence words in query
    for sentence in sentences:
        total_score = 0
        query_words = 0
        # Query words in sentence
        for word in query:
            if word in sentences[sentence]:
                total_score += idfs[word]
        # Sentence words in query
        for word in sentences[sentence]:
            if word in query:
                query_words += 1

        sentence_scores.append((sentence, total_score,
                                query_words / len(sentences[sentence])))

    # Sort sentences based on matching word measure
    # Query term density tiebreaker
    sorted_sentences = sorted(sentence_scores,
                              key=operator.itemgetter(1, 2), reverse=True)

    # for result in sorted_sentences:
    #     print(result)
    #     print("\n")

    # Return top n scoring sentences
    return sorted_sentences[0][0]


def txt_read(query, text, idfs):

    # Convert text into dict with sentence and corresponding list of words (Thanks to CSE-80 for code)
    sentences = dict()
    for sentence in split_into_sentences(text):
        # print(sentence + "\n")
        tokens = tokenize(sentence)
        if tokens:
            sentences[sentence] = tokens

    # Say the top matching answer
    return top_answer(query, sentences, idfs)


# Code for recording from https://realpython.com/playing-and-recording-sound-python/
def record(destination, seconds):
    fs = 44100  # Sample rate

    myrecording = sd.rec(int(seconds * fs), samplerate=fs, channels=2)
    sd.wait()  # Wait until recording is finished
    wavio.write(destination, myrecording, fs, sampwidth=4)  # Save as WAV file


# Code for speech-to-text from https://towardsdatascience.com/easy-speech-to-text-with-python-3df0d973b426
def stt(speech):
    # Initialize recognizer class (for recognizing the speech)
    r = sr.Recognizer()

    # Reading Audio file as source
    # listening the audio file and store in audio_text variable

    with sr.WavFile(speech) as source:

        audio_text = r.listen(source)

        # recoginize_() method will throw a request error if the API is unreachable, hence using exception handling
        try:

            # using google speech recognition
            text = r.recognize_google(audio_text)
            return text.lower()

        except:
            return 'Error'


def say(lines):
    tospeak = lines
    engine.say(tospeak)
    engine.runAndWait()


def game_select():
    while True:
        # Prompt user for game
        game = ""
        say("What game are you playing?")
        # Wait for response
        while "playing" not in game:
            record('output.wav', 5)
            game = stt('output.wav')
            print(game)

            if game != 'Error':
                break
            else:
                say("I'm sorry, I didn't get that. Could you repeat what you said?")

        # Remove question words that could interfere with understanding
        nonowords = {"i ", "we ", "am ", "are ", "playing "}
        for word in nonowords:
            game = game.replace(word, ' ')
        game = game.strip()

        game = game.replace(" ", "_")

        # Check for game file
        if game in availableGames:
            fileName = game + ".pdf"
            currentRules = pdf_to_text(fileName, "Text.txt")
            say("Current game updated")
            return currentRules
        else:
            say("I'm sorry, could you repeat")


if __name__ == '__main__':
    availableGames = ["triumph_and_tragedy", "twilight_imperium", "civilization"]
    badwords = {"what ", "is ", "are ", "how ", "do ", "when ", "the ", "i ", "we ", "you ", "our "}
    idfs = compute_idfs(load_files(availableGames))

    currentRules = game_select()
    output = ''

    # Loop forever
    while True:
        # Wait until someone calls for the program, then greet
        while 'bob' not in output:
            record('output.wav', 2)
            output = stt('output.wav')
            print(output)

        say('Hello, what do you need help with?')

        # Listen for a question
        output = 'Error'
        while output == 'Error':
            record('output.wav', 5)
            output = stt('output.wav')
            print(output)

            if output != 'Error':
                break
            else:
                say("I'm sorry, I didn't get that. Could you repeat what you said?")

        # Remove other words that could be used in the sentence
        for word in badwords:
            output = output.replace(word, ' ')
        output = output.strip()
        print(output)

        query = set()
        for word in tokenize(output):
            query.add(word)

        # Handle changing game rules
        if "new game" in output:
            currentRules = game_select()
        else:
            # Look up the person's query in the rules
            answer = txt_read(query, currentRules, idfs)
            if not answer:
                say("I'm sorry, I don't know the answer to that.")
            else:
                answer = answer.replace('\n', ' ')
                say(answer)



