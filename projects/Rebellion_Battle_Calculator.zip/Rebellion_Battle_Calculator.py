import random
import re


def empire_build():
    print('Glorious Empire, build your fleet!')
    print('Your ships are (From Strongest to Weakest): Death Stars, Super Star Destroyers, Star Destroyers, '
          'Interdictors, Assault Carriers, TIE Fighters, TIE Strikers, and Death Stars Under Construction')
    empire_fleet = {'death star': 0, 'super star destroyer': 0, 'star destroyer': 0, 'interdictor': 0,
                    'assault carrier': 0, 'tie fighter': 0, 'tie striker': 0, 'death star under construction': 0}
    print()
    cont = True
    while cont:
        newship = input('What ship type are you adding (Type in singular)?').lower()
        newnumber = int(input('How many? (No letters)'))
        if newship in empire_fleet.keys():
            empire_fleet[newship] += newnumber
            print('Added ' + str(newnumber) + ' ' + newship + "(s) to the Empire's fleet!")
            print()
        else:
            print('Did not recognize ship name. Type in singular')
            print()
        contchoice = input('Do you wish to continue? (y/n)')
        print()
        if contchoice == 'n':
            cont = False
    return empire_fleet


def rebellion_build():
    print('Traitorous Rebellion, build your pathetic fleet.')
    print('Your ships are (From Strongest to Weakest): Mon Calamari Cruisers, Nebulon-B Frigates, Corellian Corvettes, '
          'X-Wings, Y-Wings, U-Wings, and Rebel Transports')
    rebel_fleet = {'mon calamari cruiser': 0, 'nebulon-b frigate': 0, 'corellian corvette': 0, 'x-wing': 0,
                   'y-wing': 0, 'u-wing': 0, 'rebel transport': 0}
    print()
    cont = True
    while cont:
        newship = input('What ship type are you adding (Type in singular)?').lower()
        newnumber = int(input('How many? (No letters)'))
        if newship in rebel_fleet.keys():
            rebel_fleet[newship] += newnumber
            print('Added ' + str(newnumber) + ' ' + newship + "(s) to the Rebellion's fleet!")
            print()
        else:
            print('Did not recognize ship name. Type in singular')
            print()
        contchoice = input('Do you wish to continue? (y/n)')
        print()
        if contchoice == 'n':
            cont = False
    return rebel_fleet


def health_converter(p_fleet, p_player):
    ship_health = {}
    if p_player == 'empire':
        if p_fleet['death star'] > 0:
            counter = 0
            shipcount = p_fleet['death star']
            while counter < shipcount:
                ship_health.update({'death star' + str(counter): float('inf')})
                counter += 1
        if p_fleet['super star destroyer'] > 0:
            counter = 0
            shipcount = p_fleet['super star destroyer']
            while counter < shipcount:
                ship_health.update({'super star destroyer' + str(counter): 6})
                counter += 1
        if p_fleet['star destroyer'] > 0:
            counter = 0
            shipcount = p_fleet['star destroyer']
            while counter < shipcount:
                ship_health.update({'star destroyer' + str(counter): 4})
                counter += 1
        if p_fleet['interdictor'] > 0:
            counter = 0
            shipcount = p_fleet['interdictor']
            while counter < shipcount:
                ship_health.update({'interdictor' + str(counter): 4})
                counter += 1
        if p_fleet['assault carrier'] > 0:
            counter = 0
            shipcount = p_fleet['assault carrier']
            while counter < shipcount:
                ship_health.update({'assault carrier' + str(counter): 2})
                counter += 1
        if p_fleet['tie fighter'] > 0:
            counter = 0
            shipcount = p_fleet['tie fighter']
            while counter < shipcount:
                ship_health.update({'tie fighter' + str(counter): 1})
                counter += 1
        if p_fleet['tie striker'] > 0:
            counter = 0
            shipcount = p_fleet['tie striker']
            while counter < shipcount:
                ship_health.update({'tie striker' + str(counter): 1})
                counter += 1
        if p_fleet['death star under construction'] > 0:
            counter = 0
            shipcount = p_fleet['death star under construction']
            while counter < shipcount:
                ship_health.update({'death star under construction' + str(counter): 4})
                counter += 1
    elif p_player == 'rebellion':
        if p_fleet['mon calamari cruiser'] > 0:
            counter = 0
            shipcount = p_fleet['mon calamari cruiser']
            while counter < shipcount:
                ship_health.update({'mon calamari cruiser' + str(counter): 4})
                counter += 1
        if p_fleet['nebulon-b frigate'] > 0:
            counter = 0
            shipcount = p_fleet['nebulon-b frigate']
            while counter < shipcount:
                ship_health.update({'nebulon-b frigate' + str(counter): 3})
                counter += 1
        if p_fleet['corellian corvette'] > 0:
            counter = 0
            shipcount = p_fleet['corellian corvette']
            while counter < shipcount:
                ship_health.update({'corellian corvette' + str(counter): 2})
                counter += 1
        if p_fleet['x-wing'] > 0:
            counter = 0
            shipcount = p_fleet['x-wing']
            while counter < shipcount:
                ship_health.update({'x-wing' + str(counter): 1})
                counter += 1
        if p_fleet['y-wing'] > 0:
            counter = 0
            shipcount = p_fleet['y-wing']
            while counter < shipcount:
                ship_health.update({'y-wing' + str(counter): 1})
                counter += 1
        if p_fleet['u-wing'] > 0:
            counter = 0
            shipcount = p_fleet['u-wing']
            while counter < shipcount:
                ship_health.update({'u-wing' + str(counter): 1})
                counter += 1
        if p_fleet['rebel transport'] > 0:
            counter = 0
            shipcount = p_fleet['rebel transport']
            while counter < shipcount:
                ship_health.update({'rebel transport' + str(counter): 1})
                counter += 1
    return ship_health


def dice_roller(p_black, p_red, p_green):
    hits = {'black hits': 0, 'red hits': 0, 'direct hits': 0, 'special': 0, 'red special': 0, 'black special': 0,
            'black misses': 0, 'red misses': 0, 'green misses': 0, 'black direct': 0, 'red direct': 0,
            'green direct': 0, 'bonus': 0}
    if p_black > 5:
        p_black = 5
    if p_red > 5:
        p_red = 5
    if p_green > 3:
        p_green = 3
    if p_black > 0:
        counter = 0
        dice = p_black
        while counter < dice:
            roll = random.randint(1, 6)
            if roll == 6:
                hits['special'] += 1
                hits['black special'] += 1
            elif roll == 5:
                hits['direct hits'] += 1
                hits['black direct'] += 1
            elif roll > 2:
                hits['black hits'] += 1
            else:
                hits['black misses'] += 1
            counter += 1
    if p_red > 0:
        counter = 0
        dice = p_red
        while counter < dice:
            roll = random.randint(1, 6)
            if roll == 6:
                hits['special'] += 1
                hits['red special'] += 1
            elif roll == 5:
                hits['direct hits'] += 1
                hits['red direct'] += 1
            elif roll > 2:
                hits['red hits'] += 1
            else:
                hits['red misses'] += 1
            counter += 1
    if p_green > 0:
        counter = 0
        dice = p_green
        while counter < dice:
            roll = random.randint(1, 6)
            if roll > 4:
                hits['direct hits'] += 1
                hits['green direct'] += 1
            else:
                hits['green misses'] += 1
            counter += 1
    return hits


def dice_pooler(p_fleet, p_player, p_ion_cannons):
    dice = {'black': 0, 'red': 0, 'green': 0}
    if p_player == 'empire':
        if p_fleet['death star'] > 0:
            counter = 0
            shipcount = p_fleet['death star']
            while counter < shipcount:
                dice['red'] += 4
                counter += 1
        if p_fleet['super star destroyer'] > 0:
            counter = 0
            shipcount = p_fleet['super star destroyer']
            while counter < shipcount:
                dice['black'] += 2
                dice['red'] += 3
                counter += 1
        if p_fleet['star destroyer'] > 0:
            counter = 0
            shipcount = p_fleet['star destroyer']
            while counter < shipcount:
                dice['black'] += 1
                dice['red'] += 2
                counter += 1
        if p_fleet['interdictor'] > 0:
            counter = 0
            shipcount = p_fleet['interdictor']
            while counter < shipcount:
                dice['green'] += 2
                counter += 1
        if p_fleet['assault carrier'] > 0:
            counter = 0
            shipcount = p_fleet['assault carrier']
            while counter < shipcount:
                dice['black'] += 1
                dice['red'] += 1
                counter += 1
        if p_fleet['tie fighter'] > 0:
            counter = 0
            shipcount = p_fleet['tie fighter']
            while counter < shipcount:
                dice['black'] += 1
                counter += 1
        if p_fleet['tie striker'] > 0:
            counter = 0
            shipcount = p_fleet['tie striker']
            while counter < shipcount:
                dice['green'] += 1
                counter += 1
        if p_ion_cannons > 0:
            blams = p_ion_cannons * 2
            dice['red'] -= blams
    elif p_player == 'rebellion':
        if p_fleet['mon calamari cruiser'] > 0:
            counter = 0
            shipcount = p_fleet['mon calamari cruiser']
            while counter < shipcount:
                dice['black'] += 1
                dice['red'] += 2
                counter += 1
        if p_fleet['nebulon-b frigate'] > 0:
            counter = 0
            shipcount = p_fleet['nebulon-b frigate']
            while counter < shipcount:
                dice['green'] += 2
                counter += 1
        if p_fleet['corellian corvette'] > 0:
            counter = 0
            shipcount = p_fleet['corellian corvette']
            while counter < shipcount:
                dice['black'] += 1
                dice['red'] += 1
                counter += 1
        if p_fleet['x-wing'] > 0:
            counter = 0
            shipcount = p_fleet['x-wing']
            while counter < shipcount:
                dice['black'] += 1
                counter += 1
        if p_fleet['y-wing'] > 0:
            counter = 0
            shipcount = p_fleet['y-wing']
            while counter < shipcount:
                dice['red'] += 1
                counter += 1
        if p_fleet['u-wing'] > 0:
            counter = 0
            shipcount = p_fleet['u-wing']
            while counter < shipcount:
                dice['green'] += 1
                counter += 1
    return dice


def hit_assigner(p_hits, p_enemy_fleet, p_enemy_health, p_shield_generators, p_friendly_health, canheal, ion_stunned):
    black_health = ['tie fighter', 'tie striker', 'death star under construction', 'x-wing', 'y-wing', 'u-wing']
    red_health = ['super star destroyer', 'star destroyer', 'interdictor', 'assault carrier', 'mon calamari cruiser',
                  'nebulon-b frigate', 'corellian corvette', 'rebel transport']
    cont = True
    rerolls = 0
    while cont:
        print()
        print('The status of the enemy fleet:')
        for ship in p_enemy_health:
            print(ship + ': ' + str(p_enemy_health[ship]) + ' health left.')
        print()
        print('Dice to assign:')
        print('Black hits: ' + str(p_hits['black hits']))
        print('Red hits: ' + str(p_hits['red hits']))
        print('Direct hits: ' + str(p_hits['direct hits']))
        print('Black direct hits: ' + str(p_hits['black direct']))
        print('Red direct hits: ' + str(p_hits['red direct']))
        print('Green direct hits: ' + str(p_hits['green direct']))
        print('Special: ' + str(p_hits['special']))
        print('Red Special: ' + str(p_hits['red special']))
        print('Black Special: ' + str(p_hits['black special']))
        print('Bonus direct hits: ' + str(p_hits['bonus']))
        print()
        hit_type = input('What kind of hit do you want to assign? (black/red/direct/special) ').lower()
        if hit_type == 'red':
            for ship in p_enemy_fleet:
                if ship in red_health and p_enemy_fleet[ship] > 0:
                    print('Available to hit: ' + ship + 's.')
            hit_ship = input('What ship do you want to hit? (Type with name then number) ')
            hit_amount = int(input('How many hits are you assigning? (Numbers only) '))
            if re.sub('[^a-zA-Z- ]+', '', hit_ship) in red_health and hit_ship in p_enemy_health:
                if p_hits['red hits'] >= hit_amount > 0:
                    p_enemy_health[hit_ship] -= hit_amount
                    p_hits['red hits'] -= hit_amount
                else:
                    print('That is too many hits')
            else:
                print('That is not a valid ship.')
        elif hit_type == 'black':
            for ship in p_enemy_fleet:
                if ship in black_health and p_enemy_fleet[ship] > 0:
                    print('Available to hit: ' + ship + 's.')
            hit_ship = input('What ship do you want to hit? (Type with name then number) ')
            hit_amount = int(input('How many hits are you assigning? (Numbers only) '))
            if re.sub('[^a-zA-Z- ]+', '', hit_ship) in black_health and hit_ship in p_enemy_health:
                if hit_ship == 'death star under construction' and p_shield_generators:
                    print('Death star is shielded!')
                elif p_hits['black hits'] >= hit_amount > 0:
                    p_enemy_health[hit_ship] -= hit_amount
                    p_hits['black hits'] -= hit_amount
                else:
                    print('That is too many hits')
            else:
                print('That is not a valid ship.')
        elif hit_type == 'direct':
            unchosen = True
            hit_amount = int(input('How many hits are you assigning? (Numbers only) '))
            while unchosen:
                dicecolor = input('Are you using a black, red or green direct hit, or a bonus one? '
                                  '(Type black/red/green/bonus) ').lower()
                if dicecolor == 'black':
                    if p_hits['black direct'] >= hit_amount > 0:
                        p_hits['black direct'] -= hit_amount
                        unchosen = False
                    else:
                        print('Not enough hits of that type')
                elif dicecolor == 'red':
                    if p_hits['red direct'] >= hit_amount > 0:
                        p_hits['red direct'] -= hit_amount
                        unchosen = False
                    else:
                        print('Not enough hits of that type')
                elif dicecolor == 'green':
                    if p_hits['green direct'] >= hit_amount > 0:
                        p_hits['green direct'] -= hit_amount
                        unchosen = False
                    else:
                        print('Not enough hits of that type')
                elif dicecolor == 'bonus':
                    if p_hits['bonus'] >= hit_amount > 0:
                        p_hits['bonus'] -= hit_amount
                        unchosen = False
                    else:
                        print('Not enough hits of that type')
                else:
                    print('Invalid color')
            for ship in p_enemy_fleet:
                if p_enemy_fleet[ship] > 0:
                    print('Available to hit: ' + ship + 's.')
            hit_ship = input('What ship do you want to hit? (Type with name then number) ')
            if hit_ship in p_enemy_health:
                if p_hits['direct hits'] >= hit_amount > 0:
                    p_enemy_health[hit_ship] -= hit_amount
                    p_hits['direct hits'] -= hit_amount
                else:
                    print('That is too many hits')
            else:
                print('That is not a valid ship.')
        elif hit_type == 'special':
            action = input('Are you healing or re-rolling?').lower()
            if action == 'healing' and canheal:
                maxhealth = {'death star': int('inf'), 'super star destroyer': 6, 'star destroyer': 4, 'interdictor': 4,
                             'assault carrier': 2, 'tie fighter': 1, 'tie striker': 1,
                             'death star under construction': 4,
                             'mon calamari cruiser': 4, 'nebulon-b frigate': 3, 'corellian corvette': 2, 'x-wing': 1,
                             'y-wing': 1, 'u-wing': 1, 'rebel transport': 2}
                for ship in p_friendly_health:
                    if p_friendly_health[ship] < maxhealth[re.sub('[^a-zA-Z- ]+', '', ship)]:
                        print(ship + ' has ' + p_friendly_health[ship] + ' health left.')
                healingship = input('What ship are you healing? ').lower()
                if healingship in p_friendly_health and ion_stunned != healingship:
                    if healingship in red_health:
                        if p_hits['red special'] >= 1:
                            if p_friendly_health[healingship] < maxhealth[healingship]:
                                print('Healed one damage from ' + healingship)
                                p_friendly_health[healingship] += 1
                                p_hits['red special'] -= 1
                                p_hits['special'] -= 1
                            else:
                                print('Ship at maximum health')
                        else:
                            print('Not enough specials of the correct color!')
                elif healingship in black_health:
                    if p_hits['black special'] >= 1:
                        if p_friendly_health[healingship] < maxhealth[healingship]:
                            print('Healed one damage from ' + healingship)
                            p_friendly_health[healingship] += 1
                            p_hits['black special'] -= 1
                            p_hits['special'] -= 1
                        else:
                            print('Ship at maximum health')
                    else:
                        print('Not enough specials of the correct color!')
            else:
                print("Can't heal!")
            if action == 're-rolling' and rerolls < 1 <= p_hits['special']:
                print()
                unchosen = True
                while unchosen:
                    dicecolor = input('Are you using a black or red special (Type black/red) ').lower()
                    if dicecolor == 'black' and p_hits['black special'] > 0:
                        p_hits['black special'] -= 1
                        p_hits['special'] -= 1
                        unchosen = False
                    elif dicecolor == 'red' and p_hits['red special'] > 0:
                        p_hits['red special'] -= 1
                        p_hits['special'] -= 1
                        unchosen = False
                    else:
                        print('Invalid color')
                print('Dice to re-roll:')
                print('Black hits: ' + str(p_hits['black hits']))
                print('Red hits: ' + str(p_hits['red hits']))
                print('Red Special: ' + str(p_hits['red special']))
                print('Black Special: ' + str(p_hits['black special']))
                print('Red Misses: ' + str(p_hits['red misses']))
                print('Black Misses: ' + str(p_hits['black misses']))
                print('Green Misses: ' + str(p_hits['green misses']))
                print('Black direct hits: ' + str(p_hits['black direct']))
                print('Red direct hits: ' + str(p_hits['red direct']))
                print('Green direct hits: ' + str(p_hits['green direct']))
                print()
                rerolltotal = int(input('How many re-rolls do you have? (Numbers only) '))
                counter = 0
                rerolldice = {'black': 0, 'red': 0, 'green': 0}
                while rerolltotal > counter:
                    diechoice = input('What die are you re-rolling? (Type in singular)').lower()
                    if diechoice == 'black hit':
                        if p_hits['black hits'] > 0:
                            p_hits['black hits'] -= 1
                            rerolldice['black'] += 1
                            counter += 1
                        else:
                            print('Not enough black hits to re-roll.')
                    elif diechoice == 'red hit':
                        if p_hits['red hits'] > 0:
                            p_hits['red hits'] -= 1
                            rerolldice['red'] += 1
                            counter += 1
                        else:
                            print('Not enough red hits to re-roll.')
                    elif diechoice == 'red special':
                        if p_hits['red special'] > 0:
                            p_hits['red special'] -= 1
                            p_hits['special'] -= 1
                            rerolldice['red'] += 1
                            counter += 1
                        else:
                            print('Not enough red specials to re-roll.')
                    elif diechoice == 'black special':
                        if p_hits['black special'] > 0:
                            p_hits['black special'] -= 1
                            p_hits['special'] -= 1
                            rerolldice['black'] += 1
                            counter += 1
                        else:
                            print('Not enough black specials to re-roll.')
                    elif diechoice == 'black miss':
                        if p_hits['black misses'] > 0:
                            p_hits['black misses'] -= 1
                            rerolldice['black'] += 1
                            counter += 1
                        else:
                            print('Not enough black misses to re-roll.')
                    elif diechoice == 'red miss':
                        if p_hits['red misses'] > 0:
                            p_hits['red misses'] -= 1
                            rerolldice['red'] += 1
                            counter += 1
                        else:
                            print('Not enough red misses to re-roll.')
                    elif diechoice == 'green miss':
                        if p_hits['green misses'] > 0:
                            p_hits['green misses'] -= 1
                            rerolldice['green'] += 1
                            counter += 1
                        else:
                            print('Not enough green misses to re-roll.')
                    elif diechoice == 'black direct hit':
                        if p_hits['black direct'] > 0:
                            p_hits['black direct'] -= 1
                            p_hits['direct hits'] -= 1
                            rerolldice['black'] += 1
                            counter += 1
                        else:
                            print('Not enough black direct hits to re-roll.')
                    elif diechoice == 'red direct hit':
                        if p_hits['red direct'] > 0:
                            p_hits['red direct'] -= 1
                            p_hits['direct hits'] -= 1
                            rerolldice['red'] += 1
                            counter += 1
                        else:
                            print('Not enough red direct hits to re-roll.')
                    elif diechoice == 'green direct hit':
                        if p_hits['green direct'] > 0:
                            p_hits['green direct'] -= 1
                            p_hits['direct hits'] -= 1
                            rerolldice['green'] += 1
                            counter += 1
                        else:
                            print('Not enough green direct hits to re-roll.')
                    else:
                        print('Invalid dice state')
                rerolledhits = dice_roller(rerolldice['black'], rerolldice['red'], rerolldice['green'])
                for hittype in p_hits:
                    p_hits[hittype] += rerolledhits[hittype]
                rerolls += 1
            else:
                print("Can't re-roll!")
        else:
            print('Invalid die state')
        if p_hits['black hits'] + p_hits['red hits'] + p_hits['direct hits'] <= 0 and p_hits['special'] == 0:
            cont = False
        elif p_hits['black hits'] + p_hits['red hits'] + p_hits['direct hits'] <= 0:
            usespecials = input('Do you want to use your remaining specials? (Type y/n)')
            if usespecials == 'n':
                cont = False
        else:
            continuation = input('Do you wish to continue assigning hits? (Type y/n)')
            if continuation == 'n':
                cont = False
    return p_enemy_health, p_friendly_health


def tactic_card(player, playerfleet, enemyfighters, shieldgenerator, ioncannon):
    result = []
    if player == 'empire':
        tactic = input('Empire, what tactic are you using? Available tactics are: Superlaser Blast, Overwhelming '
                       'Presence, Tractor Beam, Entrapment, Reinforcements, Swarm Tactics, Intercept, and Energy Shield'
                       ' (Type the title; Bottom will be applied if top prerequisites are not met) ').lower()
        if tactic == 'swarm tactics':
            if playerfleet['tie fighter'] > 0 and playerfleet['tie fighter'] + playerfleet['tie striker'] > \
                    enemyfighters:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['damage', [0, 0, 2]]
                else:
                    result = ['damage', [1, 0, 0, 0]]
            else:
                result = ['damage', [1, 0, 0, 0]]
        elif tactic == 'entrapment':
            if playerfleet['interdictor'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['cancel', '2cards4u']
                else:
                    result = ['notactic4u']
            else:
                result = ['notactic4u']
        elif tactic == 'tractor beam':
            if playerfleet['star destroyer'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['noleader4u']
                else:
                    result = ['damage', [0, 1, 0, 0]]
            else:
                result = ['damage', [0, 1, 0, 0]]
        elif tactic == 'overwhelming presence':
            if playerfleet['super star destroyer'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['hit modifier', [0, -2, -1, 0]]
                else:
                    result = ['hit modifier', [0, -2, 0, 0]]
            else:
                result = ['hit modifier', [0, -2, 0, 0]]
        elif tactic == 'reinforcements':
            if playerfleet['assault carrier'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['hit_modifier', [-2, 0, 0, 0], 'assault carrier']
                else:
                    result = ['hit modifier', [-2, 0, 0, 0]]
            else:
                result = ['hit modifier', [-2, 0, 0, 0]]
        elif tactic == 'superlaser blast':
            if playerfleet['death star'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['laser']
                else:
                    result = ['damage', [0, 0, 1]]
            else:
                result = ['damage', [0, 0, 1]]
        elif tactic == 'intercept':
            if playerfleet['tie striker'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['whyusedis']
                else:
                    result = ['noheal4u']
            else:
                result = ['noheal4u']
        elif tactic == 'energy shield':
            if shieldgenerator:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['energy shield']
                else:
                    result = ['swap']
            else:
                result = ['swap']
    elif player == 'rebellion':
        tactic = input('Rebellion, choose your tactic. Available tactics are: Fleet Logistics, Draw Their Fire, Outrun '
                       'Them, Rogue Squadron Support, Bombing Run, Deployment, Escort, and Ion Blast.'
                       '(Type the title; Bottom will be applied if top prerequisites are not met) ').lower()
        if tactic == 'rogue squadron support':
            if playerfleet['x-wing'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['damage', [2, 0, 0, 0]]
                else:
                    result = ['damage', [1, 0, 0, 0]]
            else:
                result = ['damage', [1, 0, 0, 0]]
        elif tactic == 'escort':
            if playerfleet['rebel transport'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['hit modifier', [-1, -1, -1, 0]]
                else:
                    result = ['hit modifier', [-2, 0, 0, 0]]
            else:
                result = ['hit modifier', [-2, 0, 0, 0]]
        elif tactic == 'draw their fire':
            if playerfleet['nebulon-b frigate'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['nebulon-b']
                else:
                    result = ['swap']
            else:
                result = ['swap']
        elif tactic == 'ion blast':
            if ioncannon:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['ion cannon']
                else:
                    result = ['damage', [0, 0, 1]]
            else:
                result = ['damage', [0, 0, 1]]
        elif tactic == 'bombing run':
            if playerfleet['y-wing'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['damage', [0, 2, 0, 0]]
                else:
                    result = ['damage', [0, 1, 0, 0]]
            else:
                result = ['damage', [0, 1, 0, 0]]
        elif tactic == 'fleet logistics':
            if playerfleet['mon calamari cruiser'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['hit modifier', [0, -2, 0, 0], '2cards4u']
                else:
                    result = ['hit modifier', [0, -2, 0, 0]]
            else:
                result = ['hit modifier', [0, -2, 0, 0]]
        elif tactic == 'deployment':
            if playerfleet['u-wing'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['udumdumherrkartoffelkopf']
                else:
                    result = ['noheal4u']
            else:
                result = ['noheal4u']
        elif tactic == 'outrun them':
            if playerfleet['corellian corvette'] > 0:
                choice = input('Top or bottom?').lower()
                if choice == 'top':
                    result = ['cancel']
                else:
                    result = ['notactic4u']
            else:
                result = ['notactic4u']
    return result


def ship_killer(p_fleet, p_fleet_health):
    for ship in p_fleet_health:
        if p_fleet_health[ship] < 1:
            ship_type = re.sub('[^a-zA-Z- ]+', '', ship)
            p_fleet[ship_type] -= 1
            del p_fleet_health[ship]



def attacker_tactic():
    tactic = tactic_card(attacker, attfleet,
                         rebellion_fleet['x-wing'] + rebellion_fleet['y-wing'] + rebellion_fleet['u-wing'],
                         shielded, cannons)
    return tactic


def defender_tactic():
    tactic = tactic_card(defender, deffleet,
                         rebellion_fleet['x-wing'] + rebellion_fleet['y-wing'] + rebellion_fleet['u-wing'],
                         shielded, cannons)
    return tactic


def healing(p_friendly_health, p_hits, nebulonb):
    black_health = ['tie fighter', 'tie striker', 'death star under construction', 'x-wing', 'y-wing', 'u-wing']
    red_health = ['super star destroyer', 'star destroyer', 'interdictor', 'assault carrier',
                  'mon calamari cruiser', 'nebulon-b frigate', 'corellian corvette', 'rebel transport']
    maxhealth = {'super star destroyer': 6, 'star destroyer': 4, 'interdictor': 4, 'assault carrier': 2,
                 'tie fighter': 1, 'tie striker': 1, 'death star under construction': 4,
                 'mon calamari cruiser': 4, 'nebulon-b frigate': 3, 'corellian corvette': 2, 'x-wing': 1,
                 'y-wing': 1, 'u-wing': 1, 'rebel transport': 2}
    while p_hits['special'] > 0:
        for ship in p_friendly_health:
            if p_friendly_health[ship] < maxhealth[re.sub('[^a-zA-Z- ]+', '', ship)]:
                print(ship + ' has ' + p_friendly_health[ship] + ' health left.')
        healingship = input('What ship are you healing? ').lower()
        if healingship in p_friendly_health and ion_stunned != healingship:
            if nebulonb and re.sub('[^a-zA-Z- ]+', '', healingship) == 'nebulon-b frigate':
                print("Can't heal nebulon-b frigates!")
            if healingship in red_health:
                if p_hits['red special'] >= 1 and p_hits['special'] >= 1:
                    if p_friendly_health[healingship] < maxhealth[healingship]:
                        print('Healed one damage from ' + healingship)
                        p_friendly_health[healingship] += 1
                        p_hits['red special'] -= 1
                        p_hits['special'] -= 1
                    else:
                        print('Ship at maximum health')
                else:
                    print('Not enough specials of the correct color!')
        elif healingship in black_health:
            if p_hits['black special'] >= 1 and p_hits['special'] >= 1:
                if p_friendly_health[healingship] < maxhealth[healingship]:
                    print('Healed one damage from ' + healingship)
                    p_friendly_health[healingship] += 1
                    p_hits['black special'] -= 1
                    p_hits['special'] -= 1
                else:
                    print('Ship at maximum health')
            else:
                print('Not enough specials of the correct color!')
    return p_friendly_health


print('Welcome to the Star Wars: Rebellion battle calculator!')
print()
imperial_fleet = empire_build()
print()
rebellion_fleet = rebellion_build()
imperial_health = health_converter(imperial_fleet, 'empire')
rebellion_health = health_converter(rebellion_fleet, 'rebellion')
attacker = input('Who is the attacker? (Type rebellion/empire) ').lower()
if attacker == 'empire':
    defender = 'rebellion'
    attfleet = imperial_fleet
    deffleet = rebellion_fleet
    atthealth = imperial_health
    defhealth = rebellion_health
    first = 'empire'
    last = 'rebellion'
else:
    defender = 'empire'
    attfleet = rebellion_fleet
    deffleet = imperial_fleet
    atthealth = rebellion_health
    defhealth = imperial_health
    first = 'rebellion'
    last = 'empire'
generators = input('Are there any shield generators in the system? (Type y/n)').lower()
if generators == 'y':
    shielded = True
else:
    shielded = False
cannons = int(input('How many ion cannons are there in the system? (Numbers only) '))
attcanusetactic = True
attcanheal = True
defendercanusetactic = True
defcanheal = True
playing = True
deathcounter = 0
while playing:
    ion_stunned = ''
    att_tactic = None
    def_tactic = None
    attcanheal = True
    defcanheal = False
    if attcanusetactic:
        if att_tactic is not None:
            att_tactic.append(attacker_tactic())
        else:
            att_tactic = attacker_tactic()
    if defendercanusetactic:
        if def_tactic is not None:
            def_tactic.append(defender_tactic())
        else:
            def_tactic = defender_tactic()
    attcanusetactic = True
    defendercanusetactic = True
    if def_tactic[0] == 'cancel':
        att_tactic = ['']
    if att_tactic[0] == 'cancel':
        def_tactic = ['']
    for index, card in enumerate(att_tactic):
        if card == '2cards4u':
            for result in attacker_tactic():
                att_tactic.append(result)
        elif card == 'damage':
            resolution = hit_assigner({'black hits': att_tactic[index + 1][0], 'red hits': att_tactic[index + 1][1],
                                       'direct hits': att_tactic[index + 1][2],
                                       'special': 0, 'red special': 0, 'black special': 0, 'black misses': 0,
                                       'red misses': 0,
                                       'green misses': 0, 'black direct': 0, 'red direct': 0, 'green direct': 0,
                                       'bonus': att_tactic[index + 1][2]},
                                      deffleet, defhealth, shielded, atthealth, False, ion_stunned)
            defhealth = resolution[0]
        elif card == 'noheal4u':
            defcanheal = False
        elif card == 'laser':
            red_health = ['super star destroyer', 'star destroyer', 'interdictor', 'assault carrier',
                          'mon calamari cruiser', 'nebulon-b frigate', 'corellian corvette', 'rebel transport']
            print()
            print('Ships to hit:')
            for ship in defhealth:
                ship_converted = re.sub('[^a-zA-Z- ]+', '', ship)
                if ship_converted in red_health:
                    print(ship)
            notchoosed = True
            while notchoosed:
                print()
                kill = input('Which ship are you shooting at?').lower()
                converted_ship = ship_converted = re.sub('[^a-zA-Z- ]+', '', kill)
                if converted_ship in red_health and deffleet[converted_ship] > 0:
                    defhealth[kill] -= 5
                    notchoosed = False
                    print('Shot at ' + kill)
        elif card == 'ion cannon':
            red_health = ['super star destroyer', 'star destroyer', 'interdictor', 'assault carrier',
                          'mon calamari cruiser',
                          'nebulon-b frigate', 'corellian corvette', 'rebel transport']
            print()
            print('Ships to hit:')
            for ship in defhealth:
                ship_converted = re.sub('[^a-zA-Z- ]+', '', ship)
                if ship_converted in red_health:
                    print(ship)
            notchoosed = True
            while notchoosed:
                print()
                kill = input('Which ship are you shooting at?').lower()
                converted_ship = ship_converted = re.sub('[^a-zA-Z- ]+', '', kill)
                if converted_ship in red_health and deffleet[converted_ship] > 0:
                    ion_stunned = defhealth[kill]
                    defhealth[kill] -= 1
                    notchoosed = False
                    print('Shot at ' + kill)
        elif card == 'swap':
            first = attacker
            last = defender
        elif card == 'notactic4u':
            defendercanusetactic = False
        elif card == 'tie fighter':
            attfleet['tie fighter'] += 1
            atthealth['tie fighter'] = 1
    for index, card in enumerate(def_tactic):
        if card == '2cards4u':
            for result in defender_tactic():
                def_tactic.append(result)
        elif card == 'damage':
            resolution = hit_assigner({'black hits': def_tactic[index + 1][0], 'red hits': def_tactic[index + 1][1],
                                       'direct hits': def_tactic[index + 1][2],
                                       'special': 0, 'red special': 0, 'black special': 0, 'black misses': 0,
                                       'red misses': 0,
                                       'green misses': 0, 'black direct': 0, 'red direct': 0, 'green direct': 0,
                                       'bonus': def_tactic[index + 1][2]},
                                      attfleet, atthealth, shielded, defhealth, False, ion_stunned)
            atthealth = resolution[0]
        elif card == 'noheal4u':
            attcanheal = False
        elif card == 'laser':
            red_health = ['super star destroyer', 'star destroyer', 'interdictor', 'assault carrier',
                          'mon calamari cruiser',
                          'nebulon-b frigate', 'corellian corvette', 'rebel transport']
            print()
            print('Ships to hit:')
            for ship in atthealth:
                ship_converted = re.sub('[^a-zA-Z- ]+', '', ship)
                if ship_converted in red_health:
                    print(ship)
            notchoosed = True
            while notchoosed:
                print()
                kill = input('Which ship are you shooting at?').lower()
                converted_ship = ship_converted = re.sub('[^a-zA-Z- ]+', '', kill)
                if converted_ship in red_health and attfleet[converted_ship] > 0:
                    atthealth[kill] -= 5
                    notchoosed = False
                    print('Shot at ' + kill)
        elif card == 'ion cannon':
            red_health = ['super star destroyer', 'star destroyer', 'interdictor', 'assault carrier',
                          'mon calamari cruiser',
                          'nebulon-b frigate', 'corellian corvette', 'rebel transport']
            print()
            print('Ships to hit:')
            for ship in atthealth:
                ship_converted = re.sub('[^a-zA-Z- ]+', '', ship)
                if ship_converted in red_health:
                    print(ship)
            notchoosed = True
            while notchoosed:
                kill = input('Which ship are you shooting at?').lower()
                converted_ship = ship_converted = re.sub('[^a-zA-Z- ]+', '', kill)
                if converted_ship in red_health and attfleet[converted_ship] > 0:
                    ion_stunned = atthealth[kill]
                    atthealth[kill] -= 1
                    notchoosed = False
                    print('Shot at ' + kill)
        elif card == 'swap':
            first = defender
            last = attacker
        elif card == 'notactic4u':
            attcanusetactic = False
        elif card == 'assault carrier':
            deffleet['tie fighter'] += 1
            defhealth['tie fighter'] = 1
    if attacker == first:
        print()
        attdice = dice_pooler(attfleet, first, cannons)
        print('Attacker rolling dice')
        atthits = dice_roller(attdice['black'], attdice['red'], attdice['green'])
        for index, card in enumerate(def_tactic):
            if card == 'hit modifier':
                atthits['black hits'] -= def_tactic[index + 1][0]
                atthits['red hits'] -= def_tactic[index + 1][1]
                atthits['direct hits'] -= def_tactic[index + 1][2]
        resolution = hit_assigner(atthits, deffleet, defhealth, generators, atthealth, attcanheal, ion_stunned)
        defhealth = resolution[0]
        atthealth = resolution[1]
        print()
        defdice = dice_pooler(deffleet, last, cannons)
        print('Defender rolling dice')
        defhits = dice_roller(defdice['black'], defdice['red'], defdice['green'])
        for index, card in enumerate(def_tactic):
            if card == 'hit modifier':
                defhits['black hits'] -= def_tactic[index + 1][0]
                defhits['red hits'] -= def_tactic[index + 1][1]
                defhits['direct hits'] -= def_tactic[index + 1][2]
        resolution = hit_assigner(defhits, attfleet, atthealth, generators, defhealth, defcanheal, ion_stunned)
        atthealth = resolution[0]
        defhealth = resolution[1]
        print()
    elif defender == first:
        print()
        defdice = dice_pooler(deffleet, first, cannons)
        print('Defender rolling dice')
        defhits = dice_roller(defdice['black'], defdice['red'], defdice['green'])
        for index, card in enumerate(def_tactic):
            if card == 'hit modifier':
                defhits['black hits'] -= def_tactic[index + 1][0]
                defhits['red hits'] -= def_tactic[index + 1][1]
                defhits['direct hits'] -= def_tactic[index + 1][2]
        resolution = hit_assigner(defhits, attfleet, atthealth, generators, defhealth, defcanheal, ion_stunned)
        atthealth = resolution[0]
        defhealth = resolution[1]
        print()
        attdice = dice_pooler(attfleet, last, cannons)
        print('Attacker rolling dice')
        atthits = dice_roller(attdice['black'], attdice['red'], attdice['green'])
        for index, card in enumerate(def_tactic):
            if card == 'hit modifier':
                atthits['black hits'] -= def_tactic[index + 1][0]
                atthits['red hits'] -= def_tactic[index + 1][1]
                atthits['direct hits'] -= def_tactic[index + 1][2]
        resolution = hit_assigner(atthits, deffleet, defhealth, generators, atthealth, attcanheal, ion_stunned)
        defhealth = resolution[0]
        atthealth = resolution[1]
        print()
        for card in att_tactic:
            if card == 'energy shield':
                atthealth = healing(atthealth, {'special': 2, 'red special': 2, 'black special': 2}, False)
            elif card == 'nebulon-b':
                atthealth = healing(atthealth, {'special': 2, 'red special': 2, 'black special': 2}, True)
        for card in def_tactic:
            if card == 'energy shield':
                defhealth = healing(defhealth, {'special': 2, 'red special': 2, 'black special': 2}, False)
            elif card == 'nebulon-b':
                defhealth = healing(defhealth, {'special': 2, 'red special': 2, 'black special': 2}, True)
    ship_killer(attfleet, atthealth)
    ship_killer(deffleet, defhealth)
    if attacker == 'empire':
        rebellion_fleet = deffleet
    elif attacker == 'rebellion':
        rebellion_fleet = attfleet
    plans = input('Does the rebellion have death star plans and is there a death star in the battle? (Type y/n)')
    if plans == 'y':
        if rebellion_fleet['x-wing'] + rebellion_fleet['y-wing'] + rebellion_fleet['u-wing'] > 0 and not shielded:
            torpedo = dice_roller(3, 0, 0)
            if torpedo['direct hits'] > 0:
                if attacker == 'rebellion':
                    deffleet['death star'] -= 1
                    del defhealth['death star' + str(deathcounter)]
                    deathcounter += 1
                    print('BOOM!')
                    print('Death Star: Offline')
                elif attacker == 'empire':
                    attfleet['death star'] -= 1
                    del atthealth['death star' + str(deathcounter)]
                    deathcounter += 1
                    print('BOOM!')
                    print('Death Star: Offline')
            else:
                print('Torpedo Missed')
    att_total = 0
    def_total = 0
    for ship in attfleet:
        att_total += attfleet[ship]
    for ship in deffleet:
        def_total += deffleet[ship]
    print()
    attretreat = input('Attacker, do you retreat? (Type y/n)')
    defretreat = input('Defender, do you retreat? (Type y/n)')
    if att_total <= 0 or attretreat == 'y':
        print('Defender wins!')
        playing = False
    elif def_total <= 0 or defretreat == 'y':
        print('Attacker wins!')
        playing = False
