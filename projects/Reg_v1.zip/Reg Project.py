from PyPDF2 import PdfFileReader
from tika import parser
import sounddevice as sd
from scipy.io.wavfile import write
import speech_recognition as sr
import wavio
import pyttsx3
# Set up pyttsx3 text to speech
engine = pyttsx3.init()


# get_info from https://www.blog.pythonlibrary.org/2018/06/07/an-intro-to-pypdf2/
def get_info(path):
    with open(path, 'rb') as f:
        pdf = PdfFileReader(f)
        number_of_pages = pdf.getNumPages()
        return number_of_pages


def text_extractor(path, page):
    # Take text from pdf and convert it to a string
    with open(path, 'rb') as f:
        pdf = PdfFileReader(f)
        page = pdf.getPage(page)
        print(page)
        print('Page type: {}'.format(str(type(page))))
        text = page.extractText()
        return text


def pdf_to_text(path, towrite):
    # Write pdf text to text file
    with open(towrite, 'w', encoding='utf-8') as f:
        pagetext = parser.from_file(path)
        output = pagetext['content']
        f.write(output)
        return output


def txt_read(query, text):
    query_len = len(query)
    text_len = len(text)
    to_search = query.upper()
    output = ''
    for character_num in range(text_len):
        start_read = character_num + query_len
        end_read = start_read
        # Look for heading matching query
        if text[character_num - 1:start_read] == ' ' + to_search and text[character_num - 2].isdecimal():
            reader = start_read
            while reader < text_len:
                # Account for sections with multiple steps
                if text[reader:reader + 4] == 'STEP':
                    for i in range(reader, text_len):
                        if text[reader] == '—':
                            reader += 2
                        elif text[reader].islower():
                            break
                        else:
                            reader += 1
                # Find the next heading
                elif text[reader:reader + 4].isupper() and text[reader:reader + 4].isalpha():
                    end_read = reader
                    break
                reader += 1
            # Read from end of matching heading to beginning of next heading
            for character in range(start_read, end_read):
                output += text[character]
            return output
    return False


# Code for recording from https://realpython.com/playing-and-recording-sound-python/
def record(destination, seconds):
    fs = 44100  # Sample rate

    myrecording = sd.rec(int(seconds * fs), samplerate=fs, channels=2)
    sd.wait()  # Wait until recording is finished
    wavio.write(destination, myrecording, fs, sampwidth=4)  # Save as WAV file


# Code for speech-to-text from https://towardsdatascience.com/easy-speech-to-text-with-python-3df0d973b426
def stt(speech):
    # Initialize recognizer class (for recognizing the speech)
    r = sr.Recognizer()

    # Reading Audio file as source
    # listening the audio file and store in audio_text variable

    with sr.WavFile(speech) as source:

        audio_text = r.listen(source)

        # recoginize_() method will throw a request error if the API is unreachable, hence using exception handling
        try:

            # using google speech recognition
            text = r.recognize_google(audio_text)
            return text.lower()

        except:
            return 'Error'


def say(lines):
    tospeak = lines
    engine.say(tospeak)
    engine.runAndWait()


def game_select():
    while True:
        # Prompt user for game
        game = ""
        say("What game are you playing?")
        # Wait for response
        while "playing" not in game:
            record('output.wav', 5)
            game = stt('output.wav')
            print(game)

            if game != 'Error':
                break
            else:
                say("I'm sorry, I didn't get that. Could you repeat what you said?")

        # Remove question words that could interfere with understanding
        nonowords = {"i ", "we ", "am ", "are ", "playing "}
        for word in nonowords:
            game = game.replace(word, ' ')
        game = game.strip()

        game = game.replace(" ", "_")

        # Check for game file
        if game in availableGames:
            fileName = game + ".pdf"
            currentRules = pdf_to_text(fileName, "Text.txt")
            say("Current game updated")
            return currentRules
        else:
            say("I'm sorry, could you repeat")


if __name__ == '__main__':
    availableGames = ["imperial_assault", "twilight_imperium"]
    currentRules = game_select()
    output = ''

    # Loop forever
    while True:
        # Wait until someone calls for the program, then greet
        while 'bob' not in output:
            record('output.wav', 2)
            output = stt('output.wav')
            print(output)

        say('Hello, what do you need help with?')

        # Listen for a question
        output = 'Error'
        while output == 'Error':
            record('output.wav', 5)
            output = stt('output.wav')
            print(output)

            if output != 'Error':
                break
            else:
                say("I'm sorry, I didn't get that. Could you repeat what you said?")

        # Remove other words that could be used in the sentence
        badwords = {"what ", "is ", "are ", "how ", "do ", "when ", "the ", "i ", "we ", "you ", "our "}
        for word in badwords:
            output = output.replace(word, ' ')
        output = output.strip()
        print(output)

        # Handle changing game rules
        if "new game" in output:
            currentRules = game_select()
        else:
            # Look up the person's query in the rules
            answer = txt_read(output, currentRules)
            if not answer:
                say("I'm sorry, I don't know the answer to that.")
            else:
                answer = answer.replace('\n', ' ')
                say(answer)



